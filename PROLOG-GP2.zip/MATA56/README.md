FUNCIONAMENTO DO CÓDIGO

1. Inicialização: As listas de datashows disponíveis e alocados são inicializadas.

2. Consulta: O usuário pode consultar a lista de datashows disponíveis ou alocados a qualquer momento usando os predicados listar_disponiveis e listar_alocados.

3. Alocação: Para alocar um datashow, o usuário chama o predicado alocar com o nome do datashow desejado. O sistema verifica a disponibilidade e, se disponível, realiza a alocação.

4. Desalocação: Para desalocar um datashow, o usuário chama o predicado desalocar com o nome do datashow desejado. O sistema verifica se o datashow está alocado e, se estiver, realiza a desalocação.